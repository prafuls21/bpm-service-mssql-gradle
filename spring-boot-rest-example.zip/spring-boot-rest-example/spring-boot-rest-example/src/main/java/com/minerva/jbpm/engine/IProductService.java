package com.minerva.jbpm.engine;
import java.util.List;

import com.minerva.model.Product;
public interface IProductService 
{
List<Product> findAll();
}
