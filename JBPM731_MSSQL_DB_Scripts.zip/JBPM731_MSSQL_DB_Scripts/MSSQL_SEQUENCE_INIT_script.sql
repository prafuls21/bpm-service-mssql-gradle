INSERT INTO [dbo].[ATTACHMENT_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[AUDIT_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[BAM_TASK_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[BOOLEANEXPR_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[CASE_FILE_DATA_LOG_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[CASE_ID_INFO_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[CASE_ROLE_ASSIGN_LOG_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[COMMENT_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[CONTENT_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[CONTEXT_MAPPING_INFO_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[CORRELATION_KEY_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[CORRELATION_PROP_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[DEADLINE_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[DEPLOY_STORE_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[EMAILNOTIFHEAD_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[ERROR_INFO_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[ESCALATION_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[EXEC_ERROR_INFO_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[I18NTEXT_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[NODE_INST_LOG_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[NOTIFICATION_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[PROC_INST_LOG_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[PROCESS_INSTANCE_INFO_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[QUERY_DEF_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[REASSIGNMENT_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[REQUEST_INFO_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[SESSIONINFO_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[TASK_DEF_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[TASK_EVENT_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[TASK_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[TASK_VAR_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[VAR_INST_LOG_ID_SEQ]
            ([next_val])
     VALUES (1);

INSERT INTO [dbo].[WORKITEMINFO_ID_SEQ]
            ([next_val])
     VALUES (1); 